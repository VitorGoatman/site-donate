# chota
A really small CSS framework. 

Full details on [master](https://github.com/jenil/chota/blob/master/README.md)

To run docs locally first install Jekyll and then run:
```
jekyll serve
```
